# SpaceX DRAINER v2 by ELONLAB
Installation: source start.sh

продукт разработан и выложен в открытый доступ для канала https://t.me/elonlab